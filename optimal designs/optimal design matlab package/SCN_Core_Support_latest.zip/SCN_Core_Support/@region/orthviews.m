function orthviews(obj, varargin)

cluster_orthviews(obj, varargin{:});

end