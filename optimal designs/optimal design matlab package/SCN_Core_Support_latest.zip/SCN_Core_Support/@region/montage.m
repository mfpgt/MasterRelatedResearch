
        function montage(obj, varargin)
            montage_clusters([], obj, varargin{:})
        end