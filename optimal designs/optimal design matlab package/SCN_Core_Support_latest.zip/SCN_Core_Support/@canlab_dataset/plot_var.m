function [meandat, stedat] = plot_var(D, varname, varargin)
% Plot the mean and standard error of a variable across events.
%
% plot_var(D, varname)
%
% D is a canlab_dataset object
% varname is a valid variable name in the dataset.
%
% Examples:
% plot_var(D, 'Frustration')
% plot_var(D, 'RT')

%
% Plot the mean and standard error of a variable across events.
%
% Usage:
% ----------------------------------------------------------------------------------
% [meandat, stedat] = plot_var(D, varname, [opt inputs])
%
% Inputs:
% ----------------------------------------------------------------------------------
% D             a canlab_dataset object
% varname       the name of a valid variable to get from dataset
%               - Looks for var name at either level, returns Event level if exists at both levels
%
% [Optional inputs:]
%
% 'subjtype' : followed by name of grouping variable
%               - must be categorical subject-level variable
%               - if entered, plot lines or bars based on these categories
%               - 'eventmeans' will plot bars; without, it will plot line
%               plots across events with standard error shading
%
% 'eventmeans' : calculate and plot subject means across event-level variables
%               - if entered, will plot bar plots of means by condition
%
% 'wh_keep'   : followed by 1/0 vector of subjects to keep.
%                - must be same length as subjects
%                - subjects with value 0 will be excluded
%
% 'color'     : followed by one color for all bars, or cell array with names of colors cell for each line/bar
%
% Outputs:
% ----------------------------------------------------------------------------------
% Copyright Tor Wager, 2013

%% plot variable as a function of event number

grouping_var_name = '';
event_means = 0;
wh_keep = true(size(D.Subj_Level.id)); %everyone
% colors <- defined below
myfontsize = 22;

for i=1:length(varargin)
    if ischar(varargin{i})
        switch varargin{i}
            
            case 'subjtype'
                grouping_var_name = varargin{i+1};
                
            case 'eventmeans'
                event_means = 1;
                
            case 'wh_keep'
                wh_keep = varargin{i+1};
        end
    end
end

create_figure(varname)
set(gca, 'FontSize', myfontsize);

[dat, dcell, wh_level, descripVar] = get_var(D, varname, wh_keep);

if any(any(isnan(dat(:,:)))), warning('Some NaNs!'); end
meandat = nanmean(dat);
stedat = ste(dat);

if ~isempty(grouping_var_name)
    % We have a grouping variable
    
    %get a wh_keep for all the levels
    [grouping_var, dum, dum, descripGrp] = D.get_var(grouping_var_name, wh_keep);
    
    levels = unique(grouping_var);
    
    % colors
    colors = scn_standard_colors(length(levels));
    wh = strcmp(varargin, 'colors');
    if any(wh), colors = varargin{find(wh)+1}; end
    
    
    for i=1:length(levels)
        wh_keep_lev{i} = (D.get_var(grouping_var_name,wh_keep)==levels(i));
        
        %plot each level
        dat_level{i} = dat(wh_keep_lev{i},:);
        
        if event_means || wh_level==1
            % prep bars
            ev_means{i} = nanmean(dat_level{i}, wh_level);
            
        else
            % prep plot of events - standard error fills
            h = fill_around_line(nanmean(dat_level{i}), ste(dat_level{i}), colors{i});
            lineh(i) = plot(nanmean(dat_level{i}), 'o-', 'Color', colors{i}, 'LineWidth', 3);
        end
    end
    
    
    groupnames = regexp(descripGrp, ',', 'split'); 
    
    if event_means || wh_level==1
        % Bar plot of groups
        if wh_level==2
            barplot_columns(ev_means, prep_name(descripVar), [],'nofig', varargin{:});
        else
            barplot_columns(dat_level, prep_name(descripVar), [],'nofig', varargin{:});
        end

       
        set(gca, 'FontSize', myfontsize);
        ylabel(prep_name(descripVar));
        xlabel([]);
        
        set(gca, 'XTick', 1:length(levels), 'XTickLabel', groupnames);
        
    else
        set(gca, 'FontSize', myfontsize);

        legend(lineh, groupnames)

        xlabel('Event number');
        ylabel(prep_name(descripVar));
        
    end
    
else  % don't split by subj type
    
    if wh_level==1 %subject level variable
        barplot_columns(dat, prep_name(descripVar), [],'nofig', varargin{:});
        ylabel(descripVar); xlabel('all subjects'); set(gca, 'XTickLabel', []);

    else %event level variable

        % Average across subjects, with std. err across subjects
        h = fill_around_line(meandat, stedat, 'k');

        set(gca, 'FontSize', myfontsize);

        plot(meandat, 'k', 'LineWidth', 3);

        xlabel('Event number');

        ylabel(descripVar);
    end
end

set(gca, 'FontSize', myfontsize);


end % function


function varname = prep_name(varname)

if iscell(varname), varname = varname{1}; end

wh = varname == '_';

varname(find(wh)) = ' ';


end
