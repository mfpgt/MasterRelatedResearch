function [ver]=cluster_tool_getver();

ver='SCAN-U Cluster Tool v1.0.1';