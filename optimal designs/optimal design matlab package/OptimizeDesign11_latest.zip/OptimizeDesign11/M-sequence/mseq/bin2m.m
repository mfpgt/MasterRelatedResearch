function a=bin2m(m)

%   a=bin2m(m)
%   converts from 0 and 1s to mseq in terms of -1 and 1

a=m*2-1;


