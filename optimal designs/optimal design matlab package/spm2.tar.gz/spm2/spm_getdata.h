/* @(#)spm_getdata.h	2.3 03/05/12
   routines for accessing datatypes for images */

short getshort(short x);
unsigned short getushort(unsigned short x);
int getint(int x);
unsigned int getuint(unsigned int x);
float getfloat(float x);
double getdouble(double x);
