Deformations Toolbox.
________________________________________________________________________
                                       Disclaimer, copyright & licencing

This toolbox is free but copyright software, distributed under the
terms of the GNU General Public Licence as published by the Free
Software Foundation (either version 2, as given in file spm_LICENCE.man, or
at your option, any later version). Further details on "copyleft" can
be found at http://www.gnu.org/copyleft/. In particular, SPM is
supplied as is.  No formal support or maintenance is provided or
implied.

________________________________________________________________________

-John Ashburner

